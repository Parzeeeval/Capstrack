<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 Not Found</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: #f2f2f2;
            color: #333;
        }
        .container {
            text-align: center;
        }
        .container h1 {
            font-size: 10em;
            margin: 0;
        }
        .container h2 {
            font-size: 2em;
            margin: 0;
        }
        .container p {
            margin: 20px 0;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            font-size: 1em;
            color: #fff;
            background: #007bff;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s ease;
        }
        .btn:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>404</h1>
        <h2>Page Not Found</h2>
        <p>Sorry, but the page you are looking for does not exist, has been removed, or is temporarily unavailable.</p>
        <a href="/login" class="btn">Go to Homepage</a>
    </div>
</body>
</html>