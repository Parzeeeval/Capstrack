<?php
// Import PHPMailer classes into the global namespace
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require 'vendor/autoload.php';


$host = 'localhost';
$dbname = 'u354989168_capstrack';
$dbusername = 'u354989168_admin'; 
$dbpassword = '@Capstrackadmin2024';

$conn = new PDO("mysql:host=$host;dbname=$dbname", $dbusername, $dbpassword);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


function generatePassword($length = 8) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $gen_pass = '';

    for ($i = 0; $i < $length; $i++) {
        $randomIndex = random_int(0, $charactersLength - 1);
        $gen_pass .= $characters[$randomIndex];
    }

    return $gen_pass;
}

function generateToken($length = 16) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $gen_token = '';

    for ($i = 0; $i < $length; $i++) {
        $randomIndex = random_int(0, $charactersLength - 1);
        $gen_token .= $characters[$randomIndex];
    }

    return $gen_token;
}

function generateID(){
    global $conn; //Always use the keyword global to get the value of conn variable for sql connection
    
    $gen_id = "";

    try{
        $curr_year = date("Y");
        $curr_month = date("m");   

        $query = "SELECT * FROM sequence_tracker";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);


        if($result){
            if($curr_year == $result["current_year"]){
                $next_sequence = $result["last_sequence"];

                $next_sequence = $next_sequence + 1;

                echo "$curr_year" . "$next_sequence";

                $gen_id = $curr_year . $next_sequence;
            }

            else if($curr_year != $result["current_year"]){
                $query = "UPDATE sequence_tracker SET current_year = ?, last_sequence = ?";
                $stmt = $conn->prepare($query);
                $stmt->execute([$curr_year, 1000]);

                $query = "SELECT * FROM sequence_tracker";
                $stmt = $conn->prepare($query);
                $stmt->execute();
                $result = $stmt->fetch(PDO::FETCH_ASSOC);

                $next_sequence = $result["last_sequence"];

                $next_sequence = $next_sequence + 1;

                $gen_id = $curr_year . $next_sequence;
            }
        }

    } 

    catch(PDOException $e) {
        echo "Error: " . $e->getMessage();
    }

    return $gen_id;
}

function getLastSequence(){
    global $conn; //Always use the keyword global to get the value of conn variable for sql connection
    
    $last_sequence = 0;

    try{
        $query = "SELECT last_sequence FROM sequence_tracker";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if($result){
            $last_sequence = $result["last_sequence"] + 1;
        }
    }

    catch(PDOException $e) {
        echo "Error: " . $e->getMessage();
    }

    return $last_sequence;
}


if(isset($_POST['userInfo'])) { //The POST with userInfo is data sent from the previous php file (upload.php)
    $userInfoJson = $_POST['userInfo'];
    $userInfo = json_decode($userInfoJson, true);
    
    //put back database info here if global doesnt work


    // Create an instance; passing `true` enables exceptions
    $mail = new PHPMailer(true);

    try{
        for($r = 1; $r < count($userInfo); $r++){
          
            $sql = "SELECT email FROM users WHERE email=?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$userInfo[$r][0]]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if($result){
                echo "The email: " . $userInfo[$r][0] ." is already in use by another user, hence an email is not sent";
            }

            else if(!$result){
                $generated_password = generatePassword();
                $generated_id = generateID();
                $generated_token = generateToken();

                $sql = "INSERT into users (id, student_id, email, password, firstname, middlename, surname, status, created_at) VALUES(?,?,?,?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $result = $stmt->execute([$generated_id, $userInfo[$r][4], $userInfo[$r][0], $generated_password, $userInfo[$r][1], $userInfo[$r][2], $userInfo[$r][3], "pending", date("Y-m-d")]);
                

                //creation tokens
                $current_date = date("Y-m-d");

                $sql = "INSERT into creation_tokens(id, token, created_at, activated) VALUES(?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $result2 = $stmt->execute([$generated_id, $generated_token, $current_date, "false"]);

                
                if($result && $result2){
                    // Server settings
                    $mail->isSMTP();                                            // Send using SMTP
                    $mail->Host       = 'smtp.gmail.com';                       // Set the SMTP server to send through
                    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
                    $mail->Username   = 'capstrack.cict@gmail.com';             // SMTP username
                    $mail->Password   = 'yvcbjiylwktgzbhf';                     // SMTP password
                    $mail->SMTPSecure = 'ssl';                                  // Enable implicit TLS encryption
                    $mail->Port       = 465;                                    // TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
            
                    $mail->setFrom('capstrack.cict@gmail.com', 'Capstrack BulSU CICT');
                    $mail->addAddress($userInfo[$r][0], $userInfo[$r][1] . " " . $userInfo[$r][3]); // Add a recipient
                    $mail->addReplyTo('capstrack.cict@gmail.com', 'Capstrack BulSU CICT');
                
                    $mail->isHTML(true); // Set email format to HTML
                    $mail->Subject = 'Capstrack Account Activation';
                    
                    // HTML body content
                    $logoUrl = 'https://capstrack.tech/images/CapstrackLogo.png';
                
                    $mail->Body = '
                        <h2>Greetings! <b>'.$userInfo[$r][1].' '.$userInfo[$r][3].'</b></h2>
                        <br>

                        <h2>To activate your <b>Capstrack</b> account, click the provided link and use the provided <b>Generated Password</b></h2>

                        <br>

                        <h2>https://capstrack.tech/activate?id=' .$generated_id. '&token=' .$generated_token. '</h2>

                        <h2><b>User ID: </b>'.$generated_id.'</h2>
                        <h2><b>Generated Password: </b>'.$generated_password.'</h2>
            
                         <div style="text-align: center;">
                            <img src="'.$logoUrl.'" alt="Logo" style="width: 100px; height: 100px;">
                            <p>Made for you with love from Capstrack</p>
                            <p>Capstrack®, City of Malolos, Bulacan, Philippines</p>
                            <p><a href="https://www.Capstrack.tech" target="_blank">Capstrack.tech</a></p>
                        </div>';
                    
                    $mail->AltBody = 'Greetings! '.$userInfo[$r][1].' '.$userInfo[$r][3].'
                    To activate your Capstrack account, click the provided link and use the provided Generated Password

                    http://localhost/testlogin/activate_account.php?id=' .$generated_id.'

                    User ID:'.$generated_id.'
                    Generated Password: '.$generated_password.'

                    Made for you with love from Capstrack
                    Capstrack®, City of Malolos, Bulacan, Philippines';
                
                    // Send the email
                    if($mail->send()) {
                        echo 'Message has been sent to ' . $userInfo[$r][0] . '<br>';

                        $last_sequence = getLastSequence();

                        $query = "UPDATE sequence_tracker SET last_sequence = ?";
                        $stmt = $conn->prepare($query);
                        $result = $stmt->execute([$last_sequence]);

                        if($result){
                            //do nothing
                        }

                        else if(!$result){
                            echo "Could not updated last_sequence";
                        }

                    }
                    
                    else {
                        echo 'Message could not be sent to ' . $userInfo[$r][0] . ' Mailer Error: ' . $mail->ErrorInfo . '<br>';
                    }
                
                    // Clear all recipients and attachments for the next iteration
                    $mail->clearAddresses();
                    $mail->clearAttachments();

                     // Attachments
                    //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
                    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name     
                }

                else if(!$result){
                    echo 'Therese was a problem creating an account for ' . $userInfo[$r][0] . '<br>';
                }
            }        
        }
    }

    catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}

?>