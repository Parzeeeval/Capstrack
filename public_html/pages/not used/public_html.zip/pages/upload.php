<!DOCTYPE html>

<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Upload Excel File</title>
    </head>

    <body>
        <h2>Upload an Excel File</h2>
        <form action="" method="post" enctype="multipart/form-data">
            <label for="file">Choose an Excel file (.xlsx):</label>
            <input type="file" name="file" id="file" accept=".xlsx" required>
            <button type="submit" name="submit">Upload</button>
        </form>
        <br>

        <?php
        require 'vendor/autoload.php';

        use PhpOffice\PhpSpreadsheet\IOFactory;
        use PHPMailer\PHPMailer\PHPMailer;
        use PHPMailer\PHPMailer\SMTP;
        use PHPMailer\PHPMailer\Exception;

        if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
            $fileName = $_FILES['file']['name'];
            $fileTmpName = $_FILES['file']['tmp_name'];
            $fileExtension = pathinfo($fileName, PATHINFO_EXTENSION);

            if ($fileExtension == 'xlsx') {
                $spreadsheet = IOFactory::load($fileTmpName);
                $sheet = $spreadsheet->getActiveSheet();
                $data = $sheet->toArray();

                echo '<h3>Excel File Content:</h3>';
                echo '<table id="excelTable" border="1">';
                foreach ($data as $row) {
                    $hasValue = false;
                    foreach ($row as $cell) {
                        if (trim($cell) !== '') {
                            $hasValue = true;
                            break;
                        }
                    }

                    if ($hasValue) {
                        echo '<tr>';
                        foreach ($row as $cell) {
                            if (trim($cell) !== '') {
                                echo '<td>' . htmlspecialchars($cell) . '</td>';
                            } else {
                                echo '<td></td>'; // or skip the cell entirely
                            }
                        }
                        echo '</tr>';
                    }
                }
                echo '</table>';
            } 
            
            else {
                echo '<p>Invalid file format. Please upload an .xlsx file.</p>';
            }
        } 
        
        else {
            if (isset($_FILES['file']) && $_FILES['file']['error'] != 0) {
                echo '<p>File upload failed.</p>';
            }
        }
        ?>
        
        <button onclick="extractTableData()">Extract Table Data</button>

        <form id="userInfoForm" action="/send_email" method="post">
            <input type="hidden" id="userInfoValues" name="userInfo">
        </form>

        <script>
            function extractTableData() {
                var table = document.getElementById("excelTable");
                var data = [];

                for (var i = 0, row; row = table.rows[i]; i++) {
                    var rowData = [];
                    for (var j = 0, col; col = row.cells[j]; j++) {
                        rowData.push(col.innerText);
                    }
                    data.push(rowData);
                }
                
                var userInfoJson =JSON.stringify(data);

                document.getElementById("userInfoValues").value = userInfoJson;

                document.getElementById("userInfoForm").submit();
            }
        </script>

    </body>
</html>