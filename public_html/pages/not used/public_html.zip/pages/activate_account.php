<!DOCTYPE html>

<html>

    <head>
        <link rel="stylesheet" href="login.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.min.css">
    </head>

    <body>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

        <div class="container">
            <div class="login_form">
                <form action="" id="changepass_form" name="changepass_form" method="POST">

                    <h2 style="text-align: center;">Login</h2>

                    <input type="password" name="password1" placeholder="Generated Password" required>
                    <br><br><br>

                    <input type="password" name="password2" placeholder="New Password..." required>
                    <input type="password" name="password3" placeholder="Re-Type New Password..." required>
                    <br><br>

                    <input type="submit" value="Submit" style="text-align: center;">
                    <br>

                    <h3 id="messenger"></h3>
                </form>
            </div>
        </div>

        <?php
            $host = 'localhost';
            $dbname = 'u354989168_capstrack';
            $dbusername = 'u354989168_admin'; 
            $dbpassword = '@Capstrackadmin2024';
            
            $conn = new PDO("mysql:host=$host;dbname=$dbname",$dbusername,$dbpassword);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $id = "";
            $token = "";


             if(isset($_GET["id"]) && isset($_GET["token"])){
                $id = $_GET["id"];
                $token = $_GET["token"];
                
                if(!empty($id) && !empty($token)){
                    /* 
                    $host = 'localhost';
                    $dbname = 'u354989168_capstrack';
                    $dbusername = 'u354989168_admin'; 
                    $dbpassword = '@Capstrackadmin2024';
                    */

                    $sql = "SELECT status FROM users WHERE id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->execute([$id]);
                    $user= $stmt->fetch(PDO::FETCH_ASSOC);

                    if($user["status"] == "active" || $user["status"] == "inactive" ){ //only pending status allowed
                        header("Location: 404");
                        exit();
                    }

                    else if($user["status"] == "pending"){
                        $sql = "SELECT token, activated FROM creation_tokens WHERE id = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->execute([$id]);
                        $user = $stmt->fetch(PDO::FETCH_ASSOC);

                        if($user["token"] != $token || $user["activated"] != "false"){
                            header("Location: 404");
                            exit();
                        }
                    }
                }

                else if(empty($id) || empty($token)){
                    header("Location: /");
                    exit();
                }
            }

            if($_SERVER['REQUEST_METHOD'] === 'POST'){ //The form is from the same php file
                global $id;
                global $token;

                $curr_pass = $_POST["password1"];
                $new_pass = $_POST["password2"];
                $retype_pass = $_POST["password3"];
                
                //put back database info here if it doesnt work globally
                
                try{

                    $sql = "SELECT * FROM users WHERE id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->execute([$id]);
                    $user= $stmt->fetch(PDO::FETCH_ASSOC);

                    if($stmt){
                        $message = "";
                        $generated_pass = $user["password"];

                        if($generated_pass == $curr_pass){
                            if($curr_pass != $new_pass){
                                if($new_pass == $retype_pass){

                                    $sql = "UPDATE users SET password = ?, status = ? WHERE id = ?";
                                    $stmt = $conn->prepare($sql);
                                    $result1 = $stmt->execute([$new_pass, "active", $id]);

                                    $sql = "UPDATE creation_tokens SET activated = ? WHERE id = ?";
                                    $stmt = $conn->prepare($sql);
                                    $result2 = $stmt->execute(["true", $id]);
                                    
                                    if($result1 && $result2){
                                        echo '<script>
                                            Swal.fire({
                                                title: "Success!",
                                                text: "Successfully Changed Password!",
                                                icon: "success",
                                                confirmButtonText: "OK"
                                            }).then((result) => {
                                                if (result.isConfirmed) {
                                                    window.location.href = "/";
                                                }
                                            });
                                        </script>';
                                    }

                                    else{
                                        echo '<script>
                                            Swal.fire({
                                                title: "Error!",
                                                text: "Something went wrong",
                                                icon: "error",
                                                confirmButtonText: "OK"
                                            }).then((result) => {
                                                if (result.isConfirmed) {
                                                    window.location.href = "/";
                                                }
                                            });
                                        </script>';
                                    }
                                } 
                                
                                else if($new_pass != $retype_pass){
                                    echo '<script>
                                        Swal.fire({
                                            title: "Error",
                                            text: "New Password and Re-type password does not match",
                                            icon: "error",
                                            confirmButtonText: "OK"
                                        });
                                    </script>';
                                }
                            } 
                            
                            else if($curr_pass == $new_pass){
                                echo '<script>
                                    Swal.fire({
                                        title: "Error",
                                        text: "New password cannot be the same as generated password",
                                        icon: "error",
                                        confirmButtonText: "OK"
                                    });
                                </script>';
                            }
                        } 
                        
                        else if($generated_pass != $curr_pass){
                            echo '<script>
                                Swal.fire({
                                    title: "Error",
                                    text: "Generated Password Incorrect",
                                    icon: "error",
                                    confirmButtonText: "OK"
                                });
                            </script>';
                        }

                        /*echo "<script type='text/javascript'>
                            document.addEventListener('DOMContentLoaded', function() {
                                document.getElementById('messenger').innerText = '$message';
                            });
                        </script>";*/

                    }
                } catch(PDOException $e){
                    die("Connection failed: " . $e->getMessage());
                }
            }
        ?>
    </body>
</html>

