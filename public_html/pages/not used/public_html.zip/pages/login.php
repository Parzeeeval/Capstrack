<!DOCTYPE html>

<html>
    <head>
        <link rel="stylesheet" href="login.css">
    </head>

    <body>
        <div class="container">
            <div class="login_form">
        
                <form action="" method="POST">

                    <h2 style="text-align: center;">Login</h2>
                    
                    <input type="text" name="email" placeholder="Email..." required>

                    <br><br>

                    <input type="password" name="password" placeholder="Password..." required>

                    <br><br>

                    <input type="submit" value="Submit" style="text-align: center;">

                    <br>

                    <h3 id="messenger"></h3>

                </form>

            </div>
        </div>

        <?php 
            
            //Connect to MySQL Hostinger
            $host = 'localhost';
            $dbname = 'u354989168_capstrack';
            $dbusername = 'u354989168_admin'; 
            $dbpassword = '@Capstrackadmin2024';
            
            $conn = new PDO("mysql:host=$host;dbname=$dbname", $dbusername, $dbpassword);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
            if($_SERVER['REQUEST_METHOD'] === 'POST'){

                $email = $_POST['email'];
                $password = $_POST['password'];

                try{
                    $message = "";

                    $stmt = $conn->prepare('SELECT * FROM users WHERE email = ?');
                    $stmt->execute([$email]);
                    $user = $stmt->fetch(PDO::FETCH_ASSOC);

                    if ($user) {  
                        $stored_password = $user['password'];

                        if ($password == $stored_password) {
                            $message = "Correct user credentials";
                        } 
                        
                        else if($password != $stored_password) {
                            $message = "Incorrect user credentials";
                        }
                    }

                    else{
                        $message = "User doesn't exist";
                    }

                    echo "<script type='text/javascript'>
                        document.addEventListener('DOMContentLoaded', function() {
                            document.getElementById('messenger').innerText = '$message';
                        });
                    </script>";
                }

                catch(PDOException $e){
                    die("Connection failed: ". $e->getMessage());
                }
            }
        ?>
    </body>
</html>