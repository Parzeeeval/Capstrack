<?php
    // Increase memory limit to 512 megabytes
    ini_set('memory_limit', '1G');

    // Enable error reporting for debugging (remove this in production)
      error_reporting(E_ALL);
    
    // Get the requested URL
    $request = $_SERVER['REQUEST_URI'];

    // Remove query string
    $request = strtok($request, '?');

    // Remove leading slash
    $request = ltrim($request, '/');

    // Route the request
    switch ($request) {
        case '':
             // Serve the main page or login form
            require 'pages/landing.html';
            exit; 
            
        case 'login':
            require 'pages/login.php';
            exit; // Do nothing, proceed to show the login form

        case 'activate':
             // Check if 'id' parameter is present
            if (isset($_GET['id']) && !empty($_GET['id'])) {
                // Include activate_account.php and pass 'id' as a variable
                $id = $_GET['id'];
                require 'pages/activate_account.php';
            } 
            
            else {
                // Handle case where 'id' parameter is missing
                require 'pages/404.php'; // A custom 404 page or error handling
            }
            exit;

        case 'upload':
            require 'pages/upload.php';
            exit;

        case 'send_email':
            require 'pages/send_email.php';
            exit;

        default:
            require 'pages/404.php'; // A custom 404 page
            exit;
    }
?>
